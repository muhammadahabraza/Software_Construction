package view;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import util.Session;
import controller.AttendanceController;
import model.Attendance;
import java.util.List;

import java.util.HashMap;

public class LectureAttendance {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            showLectureAttendancePanel();
        });
    }

    public static void showLectureAttendancePanel() {
        JFrame frame = new JFrame("Lecture Attendance - Panel");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 450);
        frame.setLayout(new BorderLayout());

        String[] columns = { "Student Name", "Date", "Status" };
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0);
        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        HashMap<String, Integer> totalCount = new HashMap<>();
        HashMap<String, Integer> presentCount = new HashMap<>();

        JLabel percentLabel = new JLabel(" ");
        percentLabel.setHorizontalAlignment(SwingConstants.CENTER);
        percentLabel.setFont(new Font("Arial", Font.BOLD, 14));
        frame.add(percentLabel, BorderLayout.SOUTH);

        // ✅ Get current logged-in user
        model.User currentUser = Session.getCurrentUser();

        if (currentUser == null) {
            JOptionPane.showMessageDialog(frame, "You must be logged in to view this panel.");
            frame.dispose();
            Login.main(null);
            return;
        }

        // ✅ Check if user is a teacher
        if (currentUser.getRole().equalsIgnoreCase("teacher")) {
            int userId = currentUser.getUserId(); // ✅ Safely assigned

            JPanel inputPanel = new JPanel(new GridLayout(4, 2, 10, 10));
            AttendanceController ac = new AttendanceController();
            List<String> studentNames = ac.getAllStudentNamesFromProfile();

            if (studentNames.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "No student names found in Profile table!");
            }

            String[] studentList = studentNames.toArray(new String[0]);
            JComboBox<String> studentCombo = new JComboBox<>(studentList);

            // Date selection
            String[] days = new String[31];
            for (int i = 1; i <= 31; i++)
                days[i - 1] = String.format("%02d", i);
            String[] months = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" };
            String[] years = { "2023", "2024", "2025", "2026" };

            JComboBox<String> dayBox = new JComboBox<>(days);
            JComboBox<String> monthBox = new JComboBox<>(months);
            JComboBox<String> yearBox = new JComboBox<>(years);

            JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            datePanel.add(dayBox);
            datePanel.add(new JLabel("/"));
            datePanel.add(monthBox);
            datePanel.add(new JLabel("/"));
            datePanel.add(yearBox);

            // Attendance status
            String[] statusOptions = { "Present", "Absent" };
            JComboBox<String> statusCombo = new JComboBox<>(statusOptions);

            // Buttons
            JButton addButton = new JButton("Mark Attendance");
            JButton clearButton = new JButton("Clear");

            // Add components
            inputPanel.add(new JLabel("Student:"));
            inputPanel.add(studentCombo);
            inputPanel.add(new JLabel("Date:"));
            inputPanel.add(datePanel);
            inputPanel.add(new JLabel("Status:"));
            inputPanel.add(statusCombo);
            inputPanel.add(addButton);
            inputPanel.add(clearButton);

            frame.add(inputPanel, BorderLayout.NORTH);

            // ✅ Add Attendance Button Action
            addButton.addActionListener(e -> {
                String student = (String) studentCombo.getSelectedItem();
                String day = (String) dayBox.getSelectedItem();
                String month = (String) monthBox.getSelectedItem();
                String year = (String) yearBox.getSelectedItem();
                String status = (String) statusCombo.getSelectedItem();

                String date = year + "-" + month + "-" + day;

                if (student == null || status == null) {
                    JOptionPane.showMessageDialog(frame, "Please fill all fields.");
                    return;
                }

                int studentId = ac.getStudentIdByName(student);
                if (studentId == -1) {
                    JOptionPane.showMessageDialog(frame, "Unable to fetch Student ID.");
                    return;
                }

                Attendance attendance = new Attendance(userId, studentId, date, status);

                if (ac.isAttendanceAlreadyMarked(studentId, date)) {
                    JOptionPane.showMessageDialog(frame, "Attendance already marked...");
                    return;
                }

                boolean success = AttendanceController.markAttendance(attendance);
                if (!success) {
                    JOptionPane.showMessageDialog(frame, "Failed to save attendance to database.");
                    return;
                }

                // ✅ Update UI
                tableModel.addRow(new Object[] { student, date, status });

                totalCount.put(student, totalCount.getOrDefault(student, 0) + 1);
                if (status.equals("Present")) {
                    presentCount.put(student, presentCount.getOrDefault(student, 0) + 1);
                }

                int total = totalCount.get(student);
                int present = presentCount.getOrDefault(student, 0);
                int percent = (int) ((present / (double) total) * 100);
                percentLabel.setText("Attendance for " + student + ": " + percent + "%");

                studentCombo.setSelectedIndex(0);
                statusCombo.setSelectedIndex(0);
            });

            clearButton.addActionListener(e -> {
                studentCombo.setSelectedIndex(0);
                dayBox.setSelectedIndex(0);
                monthBox.setSelectedIndex(0);
                yearBox.setSelectedIndex(0);
                statusCombo.setSelectedIndex(0);
                percentLabel.setText(" ");
            });
        }

        frame.setVisible(true);
    }
}
