package view;

import javax.swing.*;
import java.awt.*;

import model.Profile;
import model.User;
import controller.ProfileController;
import controller.UserController;
import util.Session;

public class Login {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Login::showLoginForm);
    }

    private static void showLoginForm() {
        JFrame frame = new JFrame("Login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(350, 400);
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout(10, 10));
        JPanel fieldsPanel = new JPanel(new GridLayout(6, 1, 5, 5));
        JPanel buttonPanel = new JPanel(new GridLayout(5, 1, 3, 3));

        JTextField userField = new JTextField();
        JPasswordField passField = new JPasswordField();

        String[] roles = { "Student", "Teacher", "Administration" };
        JComboBox<String> roleComboBox = new JComboBox<>(roles);

        JButton loginBtn = new JButton("Login");
        JButton signUpBtn = new JButton("Sign Up");

        fieldsPanel.add(new JLabel("Username:"));
        fieldsPanel.add(userField);
        fieldsPanel.add(new JLabel("Password:"));
        fieldsPanel.add(passField);
        fieldsPanel.add(new JLabel("Role:"));
        fieldsPanel.add(roleComboBox);

        buttonPanel.add(loginBtn);
        buttonPanel.add(new JLabel("OR", SwingConstants.CENTER));
        buttonPanel.add(signUpBtn);

        panel.add(fieldsPanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.CENTER);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        frame.add(panel);
        frame.setVisible(true);

        UserController controller = new UserController();

        loginBtn.addActionListener(e -> {
            String username = userField.getText().trim();
            String password = new String(passField.getPassword()).trim();
            String selectedRole = roleComboBox.getSelectedItem().toString().toLowerCase();

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            User user = controller.loginUser(username, password);

            if (user != null && user.getRole().equalsIgnoreCase(selectedRole)) {
                Session.setCurrentUser(user);

                ProfileController profileController = new ProfileController();
                Profile profile = profileController.getProfileByUserId(user.getUserId());

                if ((user.getRole().equalsIgnoreCase("student") || user.getRole().equalsIgnoreCase("teacher"))
                        && profile == null) {
                    JOptionPane.showMessageDialog(frame, "Please complete your profile.");
                    frame.dispose();
                    UserProfile.main(null);
                    return;
                } else {
                    JOptionPane.showMessageDialog(frame, "Login successful!");
                    frame.dispose();

                    switch (selectedRole) {
                        case "student":
                            StudentDashBoard.main(null);
                            break;
                        case "teacher":
                            TeacherDashBoard.main(null);
                            break;
                        case "administration":
                            AdminDashBoard.main(null);
                            break;
                        default:
                            JOptionPane.showMessageDialog(null, "Unknown role selected.");
                    }
                }
            } else {
                JOptionPane.showMessageDialog(frame, "Invalid credentials or role mismatch.", "Login Failed",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        signUpBtn.addActionListener(e -> showSignUpForm(null));
    }

    private static void showSignUpForm(String prefillusername) {
        JFrame signUpFrame = new JFrame("Sign Up");
        signUpFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        signUpFrame.setSize(350, 300);
        signUpFrame.setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(6, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JTextField usernameField = new JTextField(prefillusername != null ? prefillusername : "");
        JPasswordField passField = new JPasswordField();
        JPasswordField confirmPassField = new JPasswordField();

        String[] roles = { "Student", "Teacher", "Administration" };
        JComboBox<String> roleComboBox = new JComboBox<>(roles);

        JButton signUpBtn = new JButton("Sign Up");

        panel.add(new JLabel("Username:"));
        panel.add(usernameField);
        panel.add(new JLabel("Password:"));
        panel.add(passField);
        panel.add(new JLabel("Confirm Password:"));
        panel.add(confirmPassField);
        panel.add(new JLabel("Select Role:"));
        panel.add(roleComboBox);
        panel.add(new JLabel(""));
        panel.add(signUpBtn);

        signUpFrame.add(panel);
        signUpFrame.setVisible(true);

        UserController controller = new UserController();

        signUpBtn.addActionListener(e -> {
            String username = usernameField.getText().trim();
            String password = new String(passField.getPassword()).trim();
            String confirmPassword = new String(confirmPassField.getPassword()).trim();
            String role = roleComboBox.getSelectedItem().toString().toLowerCase();

            if (username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
                JOptionPane.showMessageDialog(signUpFrame, "Please fill in all fields.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!password.equals(confirmPassword)) {
                JOptionPane.showMessageDialog(signUpFrame, "Passwords do not match.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (controller.checkUserExists(username)) {
                JOptionPane.showMessageDialog(signUpFrame, "Username already exists!", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            boolean success = controller.registerAndLoginUser(username, password, role);

            if (success) {
                JOptionPane.showMessageDialog(signUpFrame, "Sign-up successful! You are now logged in.");
                signUpFrame.dispose();
                UserProfile.main(null);
            } else {
                JOptionPane.showMessageDialog(signUpFrame, "Registration failed. Try again.", "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        });
    }
}
