package view;

import javax.swing.*;
import java.awt.*;
import model.Profile;
import controller.ProfileController;
import util.Session;

public class UserProfile {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(UserProfile::showProfileForm);
    }

    private static void showProfileForm() {
        if (Session.getCurrentUser() == null) {
            JOptionPane.showMessageDialog(null, "Please login first.", "Not Logged In", JOptionPane.ERROR_MESSAGE);
            Login.main(null);
            return;
        }

        if (Session.getCurrentUser().getRole().equalsIgnoreCase("admin")) {
            JOptionPane.showMessageDialog(null, "Admin users do not have a profile.", "Access Denied",
                    JOptionPane.WARNING_MESSAGE);
            return;
        } else {
            JFrame frame = new JFrame("Profile");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(350, 500);
            frame.setLocationRelativeTo(null);

            JPanel panel = new JPanel(new BorderLayout(10, 10));
            JPanel fieldsPanel = new JPanel(new GridLayout(10, 1, 3, 5));
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

            JTextField fullnameField = new JTextField();
            JTextField emailField = new JTextField();
            JTextField phoneField = new JTextField();
            JTextField addressField = new JTextField();
            JButton savebtn = new JButton("Save");

            fieldsPanel.add(new JLabel("Full Name:"));
            fieldsPanel.add(fullnameField);
            fieldsPanel.add(new JLabel("Email:"));
            fieldsPanel.add(emailField);
            fieldsPanel.add(new JLabel("Phone:"));
            fieldsPanel.add(phoneField);
            fieldsPanel.add(new JLabel("Address:"));
            fieldsPanel.add(addressField);
            String[] days = new String[31];
            for (int i = 1; i <= 31; i++)
                days[i - 1] = String.valueOf(i);

            String[] months = {
                    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
            };

            String[] years = new String[100];
            int currentYear = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR);
            for (int i = 0; i < 100; i++)
                years[i] = String.valueOf(currentYear - i);

            JComboBox<String> dayBox = new JComboBox<>(days);
            JComboBox<String> monthBox = new JComboBox<>(months);
            JComboBox<String> yearBox = new JComboBox<>(years);

            JPanel dobPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
            dobPanel.add(dayBox);
            dobPanel.add(monthBox);
            dobPanel.add(yearBox);

            fieldsPanel.add(new JLabel("Date of Birth:"));
            fieldsPanel.add(dobPanel);

            buttonPanel.add(savebtn);

            panel.add(fieldsPanel, BorderLayout.CENTER);
            panel.add(buttonPanel, BorderLayout.SOUTH);
            panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

            frame.add(panel);
            frame.setVisible(true);

            ProfileController controller = new ProfileController();

            savebtn.addActionListener(e -> {
                String fullname = fullnameField.getText();
                String email = emailField.getText();
                String phone = phoneField.getText();
                String address = addressField.getText();
                String dob = dayBox.getSelectedItem() + "-" + monthBox.getSelectedItem() + "-"
                        + yearBox.getSelectedItem();

                if (fullname.isEmpty() || email.isEmpty() || phone.isEmpty() || address.isEmpty() || dob.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                int userId = Session.getCurrentUser().getUserId();
                Profile profile = new Profile(userId, fullname, email, phone, address, dob);
                boolean success = controller.saveOrUpdateProfile(profile);
                if (!success) {
                    JOptionPane.showMessageDialog(frame, "Failed to update profile.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                } else {
                    JOptionPane.showMessageDialog(frame, "Profile updated successfully!");
                    StudentDashBoard.main(null);
                }
                frame.dispose();
            });
        }
    }

    public static void showProfileData() {
        ProfileController controller = new ProfileController();

        if (Session.getCurrentUser() == null) {
            Login.main(null);
            return;
        }

        if (Session.getCurrentUser().getRole().equalsIgnoreCase("admin")) {
            JOptionPane.showMessageDialog(null, "Admin users do not have a profile.", "Access Denied",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        Profile profile = controller.getProfileByUserId(Session.getCurrentUser().getUserId());

        if (profile != null) {
            JFrame frame = new JFrame("Profile");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(350, 500);
            frame.setLocationRelativeTo(null);

            JPanel panel = new JPanel(new BorderLayout(10, 10));
            JPanel fieldsPanel = new JPanel(new GridLayout(10, 1, 3, 5));
            JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
            JButton updatebtn = new JButton("Update");

            fieldsPanel.add(new JLabel("Full Name: " + profile.getFullName()));
            fieldsPanel.add(new JLabel("Email: " + profile.getEmail()));
            fieldsPanel.add(new JLabel("Phone: " + profile.getPhone()));
            fieldsPanel.add(new JLabel("Address: " + profile.getAddress()));
            fieldsPanel.add(new JLabel("Date Of Birth: " + profile.getDob()));

            buttonPanel.add(updatebtn);

            panel.add(fieldsPanel, BorderLayout.CENTER);
            panel.add(buttonPanel, BorderLayout.SOUTH);
            panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

            frame.add(panel);
            frame.setVisible(true);

            updatebtn.addActionListener(e -> {
                frame.dispose();
                showProfileForm();
            });
        } else {
            JOptionPane.showMessageDialog(null, "No profile found. Please complete your profile.");
            showProfileForm();
        }
    }

}
