package view;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import model.User;
import model.Course;
import model.Lecture;
import model.Attendance;
import controller.CourseController;
import controller.EnrollmentController;
import controller.LectureController;
import controller.AttendanceController;
import util.Session;
import util.logout;

public class StudentDashBoard {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(StudentDashBoard::showStudentDashboard);
    }

    public static void showStudentDashboard() {
        JFrame frame = new JFrame("Student Dashboard");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 600);
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        // Header
        JLabel headerLabel = new JLabel("Welcome! to Student Dashboard", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 18));
        headerLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        headerLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        panel.add(headerLabel);

        // Buttons
        JButton profileButton = new JButton("Profile");
        JButton enrollmentButton = new JButton("Enroll in Courses");
        JButton viewCoursesButton = new JButton("View Courses");
        JButton lectureButton = new JButton("Lecture Details");
        JButton attendanceViewButton = new JButton("View Attendance");
        JButton RoadmapButton = new JButton("View Roadmap");
        JButton messageButton = new JButton("Messages");
        JButton assessmentButton = new JButton("Assessment Marks");
        JButton takeQuizButton = new JButton("Take Quiz");
        JButton AssignmentButton = new JButton("Assignment");
        JButton logoutButton = new JButton("Logout");

        // Set uniform button size
        Dimension buttonSize = new Dimension(300, 40);
        JButton[] buttons = {
                profileButton, enrollmentButton, viewCoursesButton,
                lectureButton, attendanceViewButton, RoadmapButton,
                messageButton, assessmentButton, takeQuizButton,
                AssignmentButton, logoutButton
        };

        for (JButton button : buttons) {
            button.setMaximumSize(buttonSize);
            button.setAlignmentX(Component.CENTER_ALIGNMENT);
            panel.add(Box.createVerticalStrut(10));
            panel.add(button);
        }

        // Action Listeners
        logoutButton.addActionListener(e -> logout.logoutsession(frame));

        profileButton.addActionListener(e -> {
            frame.dispose();
            UserProfile.showProfileData();
        });

        assessmentButton.addActionListener(e -> {
            frame.dispose();
            new AssessmentView().setVisible(true);
        });

        enrollmentButton.addActionListener(e -> {
            frame.dispose();
            showAvailableCoursesForEnrollment(Session.getCurrentUser());
            showStudentDashboard(); // reopen dashboard after enrollment
        });

        viewCoursesButton.addActionListener(e -> {
            EnrollmentController enrollmentController = new EnrollmentController();
            List<Course> enrolledCourses = enrollmentController
                    .getApprovedCourses(Session.getCurrentUser().getUserId());

            if (enrolledCourses.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "You are not enrolled in any courses yet.");
                return;
            }

            StringBuilder message = new StringBuilder("You are enrolled in:\n\n");
            for (Course c : enrolledCourses) {
                message.append("- ").append(c.getTitle()).append(" (").append(c.getCode()).append(")\n");
            }

            JOptionPane.showMessageDialog(frame, message.toString(), "Enrolled Courses",
                    JOptionPane.INFORMATION_MESSAGE);
        });

        AssignmentButton.addActionListener(e -> {
            frame.dispose();
            AssignmentView assignmentView = new AssignmentView("student");
            assignmentView.setVisible(true);
        });

        attendanceViewButton.addActionListener(e -> {
            AttendanceController ac = new AttendanceController();
            List<Attendance> records = ac.getAttendanceForStudent(Session.getCurrentUser().getUserId());

            if (records.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "No attendance records found.");
                return;
            }

            String[] columns = { "Date", "Status", "Marked By" };
            String[][] data = new String[records.size()][3];

            for (int i = 0; i < records.size(); i++) {
                Attendance a = records.get(i);
                data[i][0] = a.getDate();
                data[i][1] = a.getStatus();
                data[i][2] = String.valueOf(a.getUserId()); // You can later show the teacher's name instead
            }

            JTable table = new JTable(data, columns);
            JScrollPane scrollPane = new JScrollPane(table);
            JOptionPane.showMessageDialog(frame, scrollPane, "Your Attendance", JOptionPane.INFORMATION_MESSAGE);
        });

        lectureButton.addActionListener(e -> {
            LectureController controller = new LectureController();
            List<Lecture> lectures = controller.getAllLectures();

            if (lectures.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "No lecture records found.");
                return;
            }

            String[] columns = { "Title", "Date", "Description", "Teacher" };
            String[][] data = new String[lectures.size()][4];

            for (int i = 0; i < lectures.size(); i++) {
                Lecture lec = lectures.get(i);
                data[i][0] = lec.getTitle();
                data[i][1] = lec.getDate();
                data[i][2] = lec.getDescription();
                data[i][3] = lec.getTeacher();
            }

            JTable table = new JTable(data, columns);
            JScrollPane scrollPane = new JScrollPane(table);
            JOptionPane.showMessageDialog(frame, scrollPane, "Lecture Details", JOptionPane.INFORMATION_MESSAGE);
        });

        RoadmapButton.addActionListener(e -> {
            frame.dispose();
            RoadmapView.showReadOnlyRoadmapView();
        });

        messageButton.addActionListener(e -> {
            frame.dispose();
            MessagesView messagesView = new MessagesView();
            messagesView.setVisible(true);
        });

        takeQuizButton.addActionListener(e -> {
            frame.dispose();
            QuizView quizView = new QuizView("take", Session.getCurrentUser().getUsername());
            quizView.setVisible(true);
        });

        frame.add(panel);
        frame.setVisible(true);
    }

    private static void showAvailableCoursesForEnrollment(User student) {
        CourseController controller = new CourseController();
        List<Course> allCourses = controller.getAllCourses();
        List<Course> enrolled = controller.getCoursesForStudent(student.getUserId());

        List<Course> notEnrolled = new java.util.ArrayList<>();
        for (Course c : allCourses) {
            if (!enrolled.contains(c)) {
                notEnrolled.add(c);
            }
        }

        if (notEnrolled.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No new courses available for enrollment.");
            return;
        }

        String[] options = new String[notEnrolled.size()];
        for (int i = 0; i < notEnrolled.size(); i++) {
            options[i] = notEnrolled.get(i).getTitle() + " (" + notEnrolled.get(i).getCode() + ")";
        }

        String selectedCourse = (String) JOptionPane.showInputDialog(null, "Select a course to enroll:",
                "Course Enrollment", JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        if (selectedCourse != null) {
            Course chosen = notEnrolled.stream()
                    .filter(c -> selectedCourse.contains(c.getCode()))
                    .findFirst().orElse(null);

            if (chosen != null) {
                EnrollmentsView.enroll(student, chosen);
            }
        }
    }
}
