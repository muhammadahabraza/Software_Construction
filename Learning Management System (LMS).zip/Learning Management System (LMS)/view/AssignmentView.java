package view;

import controller.AssignmentController;
import model.Assignment;
import model.Submission;
import util.Session;
import model.User;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class AssignmentView extends JFrame {

    private CardLayout cardLayout;
    private JPanel mainPanel;

    private AssignmentController controller = new AssignmentController();
    private String currentUser;

    public AssignmentView(String role) {
        currentUser = Session.getCurrentUser() != null ? Session.getCurrentUser().getUsername() : "unknown";

        setTitle("Assignments");
        setSize(600, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        if (role.equalsIgnoreCase("teacher")) {
            initTeacherPanel();
        } else {
            initStudentPanel();
        }

        add(mainPanel);
        setVisible(true);
    }

    public void initTeacherPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JButton addBtn = new JButton("Upload Assignment");
        addBtn.addActionListener(e -> showUploadDialog());

        panel.add(addBtn, BorderLayout.NORTH);

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false); // Prevent editing
        panel.add(new JScrollPane(textArea), BorderLayout.CENTER);

        List<Assignment> assignments = controller.getAllAssignments();
        StringBuilder sb = new StringBuilder();
        for (Assignment assignment : assignments) {
            sb.append("Assignment ID: ").append(assignment.getId()).append("\n")
                    .append("Title: ").append(assignment.getTitle()).append("\n")
                    .append("Description: ").append(assignment.getDescription()).append("\n\n");

            List<Submission> submissions = controller.getSubmissions(assignment.getId());
            for (Submission sub : submissions) {
                sb.append("    Student: ").append(sub.getStudentUsername()).append("\n")
                        .append("    File Path: ").append(sub.getSubmittedFilePath()).append("\n")
                        .append("    Marks: ").append(sub.getMarks()).append("\n");

                if (sub.getMarks() == -1) {
                    String input = JOptionPane.showInputDialog(
                            this,
                            "Enter marks for " + sub.getStudentUsername() + " (Assignment ID: " + assignment.getId()
                                    + "):");
                    try {
                        int marks = Integer.parseInt(input);
                        controller.markSubmission(sub.getId(), marks);
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(this, "Invalid input. Skipping...");
                    }
                }

                sb.append("\n");
            }
            sb.append("--------------------------------------------------\n");
        }

        textArea.setText(sb.toString());
        mainPanel.add(panel, "TEACHER");
        cardLayout.show(mainPanel, "TEACHER");
    }

    private void initStudentPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        DefaultListModel<Assignment> model = new DefaultListModel<>();
        JList<Assignment> assignmentList = new JList<>(model);

        List<Assignment> assignments = controller.getAllAssignments();
        for (Assignment a : assignments) {
            model.addElement(a);
        }

        panel.add(new JScrollPane(assignmentList), BorderLayout.CENTER);
        JButton submitBtn = new JButton("Submit Assignment");
        panel.add(submitBtn, BorderLayout.SOUTH);
        submitBtn.addActionListener(e -> {
            Assignment selected = assignmentList.getSelectedValue();
            if (selected != null) {
                List<Submission> subs = controller.getSubmissions(selected.getId());
                for (Submission s : subs) {
                    if (s.getStudentUsername().equals(currentUser)) {
                        JOptionPane.showMessageDialog(this, "You already submitted this assignment.");
                        return;
                    }
                }

                JFileChooser fileChooser = new JFileChooser();
                int result = fileChooser.showOpenDialog(this);
                if (result == JFileChooser.APPROVE_OPTION) {
                    String filePath = fileChooser.getSelectedFile().getAbsolutePath();
                    Submission submission = new Submission(
                            selected.getId(),
                            currentUser,
                            filePath);
                    boolean success = controller.submitAssignment(submission);
                    JOptionPane.showMessageDialog(this,
                            success ? "Submission successful!" : "Submission failed.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select an assignment.");
            }
        });

        mainPanel.add(panel, "STUDENT");
        cardLayout.show(mainPanel, "STUDENT");
    }

    private void showUploadDialog() {
        String title = JOptionPane.showInputDialog(this, "Enter Assignment Title:");
        String desc = JOptionPane.showInputDialog(this, "Enter Assignment Description:");
        if (title != null && desc != null && !title.trim().isEmpty() && !desc.trim().isEmpty()) {
            Assignment assignment = new Assignment();
            assignment.setTitle(title.trim());
            assignment.setDescription(desc.trim());
            assignment.setUploadedBy(currentUser); // ✅ this was missing earlier

            boolean success = controller.uploadAssignment(assignment);
            if (success) {
                JOptionPane.showMessageDialog(this, "Assignment Uploaded.");
                dispose();
                new AssignmentView("teacher");
            } else {
                JOptionPane.showMessageDialog(this, "Upload Failed.");
            }
        }
    }

    public static void main(String[] args) {
        User currentUser = Session.getCurrentUser();
        if (currentUser != null) {
            new AssignmentView(currentUser.getRole());
        } else {
            JOptionPane.showMessageDialog(null, "No user is logged in.");
        }
    }
}
