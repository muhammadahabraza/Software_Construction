package view;

import controller.AssessmentController;
import dao.QuizDAO;
import dao.SubmissionDAO;
import dao.UserDAO;
import model.Assessment;
import util.Session;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class AssessmentView extends JFrame {

    private AssessmentController controller = new AssessmentController();
    private String currentUser = Session.getCurrentUser().getUsername();
    private String role = Session.getCurrentUser().getRole();

    private JComboBox<String> studentCombo;
    private JTextField quizField, assignmentField, examField;
    private JButton fetchMarksButton, saveButton;

    public AssessmentView() {
        setTitle("Assessment Marks");
        setSize(450, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());

        if (role.equalsIgnoreCase("teacher")) {
            panel.add(initTeacherPanel(), BorderLayout.CENTER);
        } else {
            panel.add(initStudentPanel(), BorderLayout.CENTER);
        }

        add(panel);
        setVisible(true);
    }

    private JPanel initTeacherPanel() {
        JPanel formPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        List<String> students = UserDAO.getAllStudents();
        studentCombo = new JComboBox<>(students.toArray(new String[0]));

        quizField = new JTextField();
        assignmentField = new JTextField();
        examField = new JTextField();

        fetchMarksButton = new JButton("Auto-Fill Quiz & Assignment");
        saveButton = new JButton("Save / Update Marks");

        formPanel.add(new JLabel("Student Username:"));
        formPanel.add(studentCombo);

        formPanel.add(new JLabel("Quiz Marks:"));
        formPanel.add(quizField);

        formPanel.add(new JLabel("Assignment Marks:"));
        formPanel.add(assignmentField);

        formPanel.add(new JLabel("Exam Marks:"));
        formPanel.add(examField);

        formPanel.add(fetchMarksButton);
        formPanel.add(saveButton);

        // Auto-fill marks
        fetchMarksButton.addActionListener(e -> {
            String selectedUser = (String) studentCombo.getSelectedItem();
            int quiz = QuizDAO.getQuizScore(selectedUser);
            int assignment = SubmissionDAO.getSubmissionScore(selectedUser);

            quizField.setText(String.valueOf(quiz));
            assignmentField.setText(String.valueOf(assignment));
        });

        saveButton.addActionListener(e -> {
            String studentUsername = (String) studentCombo.getSelectedItem();
            try {
                int quiz = Integer.parseInt(quizField.getText().trim());
                int assignment = Integer.parseInt(assignmentField.getText().trim());
                int exam = Integer.parseInt(examField.getText().trim());

                boolean success = controller.saveOrUpdateAssessment(studentUsername, quiz, assignment, exam);
                JOptionPane.showMessageDialog(this, success ? "Marks saved!" : "Failed to save marks.");

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Enter valid numbers for all fields.");
            }
        });

        return formPanel;
    }

    private JPanel initStudentPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        Assessment a = controller.getAssessment(currentUser);

        if (a != null) {
            JPanel fieldsPanel = new JPanel(new GridLayout(10, 1, 3, 5));
            fieldsPanel.add(new JLabel("Quiz Marks: " + a.getQuizMarks()));
            fieldsPanel.add(new JLabel("Assignment Marks: " + a.getAssignmentMarks()));
            fieldsPanel.add(new JLabel("Exam Marks: " + a.getExamMarks()));
            panel.add(fieldsPanel, BorderLayout.CENTER);
        } else {
            JTextArea displayArea = new JTextArea("No marks available yet.");
            displayArea.setEditable(false);
            panel.add(displayArea, BorderLayout.CENTER);
        }

        return panel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(AssessmentView::new);
    }
}
