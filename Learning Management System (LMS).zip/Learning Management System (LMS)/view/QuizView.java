package view;

import javax.swing.*;
import controller.QuizController;
import dao.QuizDAO.Question;
import util.Session;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class QuizView extends JFrame {

    private CardLayout cardLayout;
    private JPanel mainPanel;

    private String studentUsername;

    private JTextField quizNumberField;
    private JTextField questionField;
    private JTextField[] optionFields;
    private JComboBox<String> correctAnswerDropdown;
    private JButton addQuestionButton;

    private JLabel questionLabel;
    private JRadioButton[] options;
    private ButtonGroup optionGroup;
    private JButton nextButton, submitButton;
    private JLabel feedbackLabel;

    private List<String> selectedAnswers = new ArrayList<>();
    private List<String> questions = new ArrayList<>();
    private List<String[]> choices = new ArrayList<>();
    private List<Integer> correctAnswers = new ArrayList<>();

    private int currentQuestionIndex = 0;
    private int score = 0;

    private final QuizController controller = new QuizController();
    private int quizNumber = -1; // Dynamically set

    public QuizView(String mode, String studentUsername) {
        this.studentUsername = studentUsername;
        setTitle("Quiz Panel");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        add(mainPanel);

        if (mode.equalsIgnoreCase("create")) {
            initCreateQuizPanel();
            cardLayout.show(mainPanel, "CREATE");
        } else {
            String input = JOptionPane.showInputDialog(this, "Enter quiz number to attempt:");
            if (input == null || input.isEmpty()) {
                dispose();
                return;
            }

            try {
                quizNumber = Integer.parseInt(input.trim());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Invalid quiz number.");
                dispose();
                return;
            }

            if (controller.hasAttempted(studentUsername, quizNumber)) {
                JOptionPane.showMessageDialog(this, "You have already submitted this quiz.");
                dispose();
                return;
            }

            loadQuizFromDatabase();
            if (questions.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No quiz questions available.");
                dispose();
                return;
            }

            initTakeQuizPanel();
            displayQuestion();
            cardLayout.show(mainPanel, "TAKE");
            setVisible(true);
        }
    }

    private void initCreateQuizPanel() {
        JPanel createPanel = new JPanel(new GridLayout(9, 1, 5, 5));
        createPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        quizNumberField = new JTextField();

        createPanel.add(new JLabel("Quiz Number:"));
        createPanel.add(quizNumberField);

        questionField = new JTextField();
        optionFields = new JTextField[4];
        for (int i = 0; i < 4; i++) {
            optionFields[i] = new JTextField();
        }

        correctAnswerDropdown = new JComboBox<>(new String[] { "Option 1", "Option 2", "Option 3", "Option 4" });
        addQuestionButton = new JButton("Add Question");

        createPanel.add(new JLabel("Enter Question:"));
        createPanel.add(questionField);
        for (int i = 0; i < 4; i++) {
            createPanel.add(new JLabel("Option " + (i + 1) + ":"));
            createPanel.add(optionFields[i]);
        }
        createPanel.add(new JLabel("Select Correct Answer:"));
        createPanel.add(correctAnswerDropdown);
        createPanel.add(addQuestionButton);

        addQuestionButton.addActionListener(e -> {
            int enteredQuizNumber;
            try {
                enteredQuizNumber = Integer.parseInt(quizNumberField.getText().trim());
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid quiz number.");
                return;
            }

            String question = questionField.getText().trim();
            String[] options = new String[4];
            for (int i = 0; i < 4; i++) {
                options[i] = optionFields[i].getText().trim();
            }
            int correct = correctAnswerDropdown.getSelectedIndex();

            if (question.isEmpty() || options[0].isEmpty() || options[1].isEmpty() || options[2].isEmpty()
                    || options[3].isEmpty()) {
                JOptionPane.showMessageDialog(this, "Fill all fields.");
                return;
            }

            boolean success = controller.createQuizQuestion(enteredQuizNumber, question, options, correct);
            if (success) {
                JOptionPane.showMessageDialog(this, "Question added to database!");
                questionField.setText("");
                for (JTextField field : optionFields)
                    field.setText("");
                correctAnswerDropdown.setSelectedIndex(0);
            } else {
                JOptionPane.showMessageDialog(this, "Failed to save question.");
            }
        });

        mainPanel.add(createPanel, "CREATE");
    }

    private void loadQuizFromDatabase() {
        List<Question> dbQuestions = controller.loadQuizQuestions(quizNumber);
        for (Question q : dbQuestions) {
            questions.add(q.getQuestionText());
            choices.add(q.getOptions());
            correctAnswers.add(q.getCorrectIndex());
        }
    }

    private void initTakeQuizPanel() {
        JPanel takePanel = new JPanel(new BorderLayout());

        questionLabel = new JLabel();
        questionLabel.setFont(new Font("Arial", Font.BOLD, 16));
        questionLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        takePanel.add(questionLabel, BorderLayout.NORTH);

        JPanel optionPanel = new JPanel(new GridLayout(4, 1));
        optionGroup = new ButtonGroup();
        options = new JRadioButton[4];
        for (int i = 0; i < 4; i++) {
            options[i] = new JRadioButton();
            optionGroup.add(options[i]);
            optionPanel.add(options[i]);
        }
        takePanel.add(optionPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        JPanel buttonPanel = new JPanel(new FlowLayout());

        nextButton = new JButton("Next");
        submitButton = new JButton("Submit");
        buttonPanel.add(submitButton);
        buttonPanel.add(nextButton);

        feedbackLabel = new JLabel(" ");
        feedbackLabel.setHorizontalAlignment(SwingConstants.CENTER);
        feedbackLabel.setFont(new Font("Arial", Font.ITALIC, 14));

        bottomPanel.add(buttonPanel, BorderLayout.NORTH);
        bottomPanel.add(feedbackLabel, BorderLayout.SOUTH);

        takePanel.add(bottomPanel, BorderLayout.SOUTH);

        nextButton.addActionListener(e -> goToNextQuestion());
        submitButton.addActionListener(e -> goToNextQuestion());

        mainPanel.add(takePanel, "TAKE");
    }

    private void displayQuestion() {
        optionGroup.clearSelection();
        questionLabel.setText("Q" + (currentQuestionIndex + 1) + ": " + questions.get(currentQuestionIndex));
        for (int i = 0; i < 4; i++) {
            options[i].setText(choices.get(currentQuestionIndex)[i]);
        }
        feedbackLabel.setText(" ");
    }

    private void goToNextQuestion() {
        int selected = -1;
        for (int i = 0; i < options.length; i++) {
            if (options[i].isSelected()) {
                selected = i;
                break;
            }
        }

        if (selected == -1) {
            feedbackLabel.setText("Please select an answer.");
            return;
        }

        String selectedText = choices.get(currentQuestionIndex)[selected];
        selectedAnswers.add(selectedText);

        String correctText = choices.get(currentQuestionIndex)[correctAnswers.get(currentQuestionIndex)];
        if (selectedText.equals(correctText)) {
            score++;
            feedbackLabel.setText("Correct!");
        } else {
            feedbackLabel.setText("Incorrect.");
        }

        if (currentQuestionIndex < questions.size() - 1) {
            currentQuestionIndex++;
            displayQuestion();
        } else {
            saveQuizToDatabase();
            submitButton.setEnabled(false);
            JOptionPane.showMessageDialog(this, "Quiz Finished! Score: " + score + "/" + questions.size());
            dispose();
        }
    }

    private void saveQuizToDatabase() {
        for (int i = 0; i < questions.size(); i++) {
            String question = questions.get(i);
            String selected = selectedAnswers.get(i);
            String correct = choices.get(i)[correctAnswers.get(i)];
            int marks = selected.equals(correct) ? 1 : 0;
            controller.submitQuizAttempt(studentUsername, quizNumber, question, selected, correct, marks);
        }
    }

    public static void main(String[] args) {
        String studentUsername = Session.getCurrentUser().getUsername();
        SwingUtilities.invokeLater(() -> new QuizView("take", studentUsername));
    }
}
