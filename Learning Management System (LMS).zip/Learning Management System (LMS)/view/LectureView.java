package view;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import controller.LectureController;
import model.Lecture;
import java.util.List;

public class LectureView {

    private LectureController lectureController = new LectureController();

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LectureView().showLectureForm();
        });
    }

    public void showLectureForm() {
        JFrame frame = new JFrame("Create Lecture - Teacher Panel");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 450);
        frame.setLayout(new BorderLayout());

        String[] columns = { "Title", "Date", "Description", "Teacher" };
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0);
        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        // 🟢 Preload existing lectures
        List<Lecture> lectures = lectureController.getAllLectures();
        for (Lecture lec : lectures) {
            tableModel.addRow(new Object[] {
                    lec.getTitle(), lec.getDate(), lec.getDescription(), lec.getTeacher()
            });
        }

        JPanel inputPanel = new JPanel(new GridLayout(5, 2, 10, 10));
        JTextField titleField = new JTextField();
        JTextField descField = new JTextField();
        JTextField teacherField = new JTextField();

        String[] days = new String[31];
        for (int i = 1; i <= 31; i++)
            days[i - 1] = String.format("%02d", i);

        String[] months = { "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" };
        String[] years = { "2023", "2024", "2025", "2026" };

        JComboBox<String> dayBox = new JComboBox<>(days);
        JComboBox<String> monthBox = new JComboBox<>(months);
        JComboBox<String> yearBox = new JComboBox<>(years);

        JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        datePanel.add(dayBox);
        datePanel.add(new JLabel("/"));
        datePanel.add(monthBox);
        datePanel.add(new JLabel("/"));
        datePanel.add(yearBox);

        JButton addButton = new JButton("Add Lecture");
        JButton clearButton = new JButton("Clear Fields");

        inputPanel.add(new JLabel("Lecture Title:"));
        inputPanel.add(titleField);
        inputPanel.add(new JLabel("Date (DD/MM/YYYY):"));
        inputPanel.add(datePanel);
        inputPanel.add(new JLabel("Description:"));
        inputPanel.add(descField);
        inputPanel.add(new JLabel("Teacher Name:"));
        inputPanel.add(teacherField);
        inputPanel.add(addButton);
        inputPanel.add(clearButton);

        frame.add(inputPanel, BorderLayout.NORTH);

        addButton.addActionListener(e -> {
            String title = titleField.getText().trim();
            String desc = descField.getText().trim();
            String teacher = teacherField.getText().trim();
            String date = dayBox.getSelectedItem() + "/" +
                    monthBox.getSelectedItem() + "/" +
                    yearBox.getSelectedItem();

            if (title.isEmpty() || desc.isEmpty() || teacher.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill all fields.");
                return;
            }

            Lecture lecture = new Lecture(title, date, desc, teacher);

            if (lectureController.insertLecture(lecture)) {
                tableModel.addRow(new Object[] { title, date, desc, teacher });
                JOptionPane.showMessageDialog(frame, "Lecture added successfully.");
            } else {
                JOptionPane.showMessageDialog(frame, "Failed to add lecture.", "Error", JOptionPane.ERROR_MESSAGE);
            }

            titleField.setText("");
            descField.setText("");
            teacherField.setText("");
            dayBox.setSelectedIndex(0);
            monthBox.setSelectedIndex(0);
            yearBox.setSelectedIndex(0);
        });

        clearButton.addActionListener(e -> {
            titleField.setText("");
            descField.setText("");
            teacherField.setText("");
            dayBox.setSelectedIndex(0);
            monthBox.setSelectedIndex(0);
            yearBox.setSelectedIndex(0);
        });

        frame.setVisible(true);
    }
}
