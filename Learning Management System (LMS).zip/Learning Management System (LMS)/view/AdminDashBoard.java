package view;

import util.logout;
import javax.swing.*;
import java.awt.*;
import controller.CourseController;

public class AdminDashBoard {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(AdminDashBoard::showAdminDashboard);
    }

    public static void showAdminDashboard() {
        JFrame frame = new JFrame("Admin Dashboard");
        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        // Header
        JLabel headerLabel = new JLabel("Welcome! to Admin Dashboard", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 18));
        headerLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        headerLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        panel.add(headerLabel);

        // Buttons
        JButton manageEnrollmentsBtn = new JButton("Manage Enrollments");
        JButton addCourseBtn = new JButton("Add New Course");
        JButton addRoadmapBtn = new JButton("Add Roadmap Module");
        JButton viewCoursesBtn = new JButton("View All Courses");
        JButton logoutBtn = new JButton("Logout");

        JButton[] buttons = {
                manageEnrollmentsBtn, addCourseBtn,
                viewCoursesBtn, addRoadmapBtn, logoutBtn
        };

        Dimension buttonSize = new Dimension(300, 40);

        for (JButton btn : buttons) {
            btn.setMaximumSize(buttonSize);
            btn.setAlignmentX(Component.CENTER_ALIGNMENT);
            panel.add(Box.createVerticalStrut(10));
            panel.add(btn);
        }

        // Action Listeners
        manageEnrollmentsBtn.addActionListener(e -> {
            EnrollmentsView.showEnrollmentApprovalFrame();
        });

        addCourseBtn.addActionListener(e -> {
            CourseView.addCourseDialog(new CourseController(), frame);
            frame.dispose();
        });

        viewCoursesBtn.addActionListener(e -> {
            CourseView.showCourseView();
            frame.dispose();
        });

        addRoadmapBtn.addActionListener(e -> {
            RoadmapView.showRoadmapView();
            frame.dispose();
        });

        logoutBtn.addActionListener(e -> logout.logoutsession(frame));

        frame.add(panel);
        frame.setVisible(true);
    }
}
