package view;

import javax.swing.*;
import java.awt.*;

public class TeacherDashBoard {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(TeacherDashBoard::showTeacherDashboard);
    }

    private static void showTeacherDashboard() {
        JFrame frame = new JFrame("Teacher Dashboard");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 600);
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        // Header label
        JLabel headerLabel = new JLabel("Welcome! to Teacher Dashboard", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 18));
        headerLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        headerLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        panel.add(headerLabel);

        // Create buttons
        JButton profileButton = new JButton("Profile");
        JButton attendanceButton = new JButton("Lecture Attendance");
        JButton createLectureButton = new JButton("Create Lecture");
        JButton messagesButton = new JButton("Messages");
        JButton quizCreateButton = new JButton("Create Quiz");
        JButton assignmentButton = new JButton("Add Assignments");
        JButton assessmentButton = new JButton("Assessment Marks");
        JButton logoutButton = new JButton("Logout");

        // Common size for buttons
        Dimension buttonSize = new Dimension(300, 40);
        JButton[] buttons = {
                profileButton, attendanceButton, createLectureButton,
                messagesButton, quizCreateButton, assignmentButton,
                assessmentButton, logoutButton
        };

        for (JButton button : buttons) {
            button.setMaximumSize(buttonSize);
            button.setAlignmentX(Component.CENTER_ALIGNMENT);
            panel.add(Box.createVerticalStrut(10)); // space between buttons
            panel.add(button);
        }

        // Action Listeners
        profileButton.addActionListener(e -> {
            frame.dispose();
            UserProfile.showProfileData();
        });

        assessmentButton.addActionListener(e -> {
            frame.dispose();
            new AssessmentView().setVisible(true);
        });

        attendanceButton.addActionListener(e -> {
            frame.dispose();
            LectureAttendance.main(new String[0]);
        });

        createLectureButton.addActionListener(e -> {
            frame.dispose();
            new LectureView().showLectureForm();
        });

        messagesButton.addActionListener(e -> {
            frame.dispose();
            new MessagesView().setVisible(true);
        });

        quizCreateButton.addActionListener(e -> {
            frame.dispose();
            new QuizView("create", null).setVisible(true);
        });

        assignmentButton.addActionListener(e -> {
            frame.dispose();
            new AssignmentView("teacher").setVisible(true);
        });

        logoutButton.addActionListener(e -> {
            frame.dispose();
            Login.main(new String[0]);
        });

        frame.add(panel);
        frame.setVisible(true);
    }
}
