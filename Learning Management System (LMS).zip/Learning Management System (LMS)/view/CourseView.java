package view;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import model.Course;
import model.User;
import util.Session;
import controller.CourseController;
import controller.UserController;

public class CourseView {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(CourseView::showCourseView);
    }

    public static void showCourseView() {
        JFrame frame = new JFrame("Course List");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(500, 400);
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel(new BorderLayout(10, 10));
        JTextArea courseArea = new JTextArea();
        courseArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(courseArea);

        panel.add(scrollPane, BorderLayout.CENTER);
        frame.add(panel);

        String role = Session.getCurrentUser().getRole().toLowerCase();
        int userId = Session.getCurrentUser().getUserId();

        CourseController controller = new CourseController();
        List<Course> courses;

        switch (role) {
            case "student":
                courses = controller.getCoursesForStudent(userId);
                courseArea.setText("Courses Enrolled:\n\n");
                break;
            case "teacher":
                courses = controller.getCoursesForTeacher(userId);
                courseArea.setText("Courses Assigned to You:\n\n");
                break;
            default:
                courses = controller.getAllCourses(); // or empty
                courseArea.setText("All Courses (Admin View):\n\n");
                break;
        }

        if (courses.isEmpty()) {
            courseArea.append("No courses found.");
        } else {
            for (Course c : courses) {
                courseArea.append("Course Code: " + c.getCode() + "\n");
                courseArea.append("Title: " + c.getTitle() + "\n");
                courseArea.append("Description: " + c.getDescription() + "\n");
                courseArea.append("Instructor ID: " + c.getInstructorId() + "\n");
                courseArea.append("---------------\n");
            }
        }
        if (role.equals("admin")) {
            JButton addCourseBtn = new JButton("Add New Course");
            addCourseBtn.addActionListener(e -> addCourseDialog(controller, frame));

            JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
            bottomPanel.add(addCourseBtn);
            panel.add(bottomPanel, BorderLayout.SOUTH);
        }

        frame.setVisible(true);
    }

    public static void addCourseDialog(CourseController controller, JFrame parentFrame) {
        JTextField idField = new JTextField();
        JTextField titleField = new JTextField();
        JTextField codeField = new JTextField();
        JTextField descField = new JTextField();
        JTextField instructorField = new JTextField();

        JPanel formPanel = new JPanel(new GridLayout(5, 2));
        formPanel.add(new JLabel("Course ID:"));
        formPanel.add(idField);
        formPanel.add(new JLabel("Title:"));
        formPanel.add(titleField);
        formPanel.add(new JLabel("Code:"));
        formPanel.add(codeField);
        formPanel.add(new JLabel("Description:"));
        formPanel.add(descField);
        formPanel.add(new JLabel("Instructor ID:"));
        formPanel.add(instructorField);

        // If user is a teacher, fill and disable instructor field
        if (Session.getCurrentUser().getRole().equalsIgnoreCase("teacher")) {
            int teacherId = Session.getCurrentUser().getUserId();
            instructorField.setText(String.valueOf(teacherId));
            instructorField.setEditable(false);
        }

        int result = JOptionPane.showConfirmDialog(parentFrame, formPanel, "Add New Course",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            String id = idField.getText().trim();
            String title = titleField.getText().trim();
            String code = codeField.getText().trim();
            String desc = descField.getText().trim();

            int instructorId;

            try {
                instructorId = Integer.parseInt(instructorField.getText().trim());
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(parentFrame, "Invalid instructor ID", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            UserController userController = new UserController();
            User instructor = userController.getUserById(instructorId);

            if (instructor == null || !instructor.getRole().equalsIgnoreCase("teacher")) {
                JOptionPane.showMessageDialog(parentFrame,
                        "Invalid Instructor ID: No such teacher found.",
                        "Validation Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            Course newCourse = new Course(id, title, code, desc, instructorId);
            boolean success = controller.addCourse(newCourse);

            if (success) {
                JOptionPane.showMessageDialog(parentFrame, "Course added successfully!");
                parentFrame.dispose();
                showCourseView(); // refresh view
            } else {
                JOptionPane.showMessageDialog(parentFrame, "Failed to add course", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

}
