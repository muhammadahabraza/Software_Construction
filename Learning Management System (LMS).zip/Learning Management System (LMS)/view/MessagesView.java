package view;

import javax.swing.*;
import java.awt.*;
import java.util.List;

import controller.MessageController;
import dao.UserDAO;
import model.Message;
import util.Session;

public class MessagesView extends JFrame {

    private JTextArea messageArea;
    private JTextField inputField;
    private JButton sendButton, refreshButton;
    private JComboBox<String> receiverDropdown;

    private final MessageController controller = new MessageController();

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MessagesView().setVisible(true));
    }

    public MessagesView() {
        setTitle("LMS Message System");
        setSize(550, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        initComponents();
        addListeners();

        loadMessages(); // Load messages on startup
    }

    private void initComponents() {
        // Message display
        messageArea = new JTextArea();
        messageArea.setEditable(false);
        messageArea.setLineWrap(true);
        messageArea.setWrapStyleWord(true);
        add(new JScrollPane(messageArea), BorderLayout.CENTER);

        // Top panel (receiver dropdown and refresh)
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        receiverDropdown = new JComboBox<>();
        populateReceiverDropdown(); // 🔥 add this line to load from DB
        refreshButton = new JButton("Refresh");
        topPanel.add(new JLabel("To:"));
        topPanel.add(receiverDropdown);
        topPanel.add(refreshButton);
        add(topPanel, BorderLayout.NORTH);

        // Bottom panel (input field and send button)
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputField = new JTextField();
        inputField.setBackground(Color.pink);
        sendButton = new JButton("Send");
        inputPanel.add(inputField, BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);
        add(inputPanel, BorderLayout.SOUTH);
    }

    private void addListeners() {
        sendButton.addActionListener(e -> sendMessage());
        inputField.addActionListener(e -> sendMessage());
        refreshButton.addActionListener(e -> loadMessages());
    }

    private void sendMessage() {
        String receiver = (String) receiverDropdown.getSelectedItem();
        String content = inputField.getText().trim();

        if ("Select User".equals(receiver) || content.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please select a receiver and write a message.");
            return;
        }

        Message msg = new Message(
                Session.getCurrentUser().getUsername(),
                receiver,
                "No Subject",
                content);

        if (controller.sendMessage(msg)) {
            inputField.setText("");
            loadMessages();
        } else {
            JOptionPane.showMessageDialog(this, "Message sending failed.");
        }
    }

    private void loadMessages() {
        try {
            String receiver = (String) receiverDropdown.getSelectedItem();
            String currentUser = Session.getCurrentUser().getUsername();
            messageArea.setText("");

            if ("Select User".equals(receiver))
                return;

            List<Message> messages = controller.getMessagesBetween(currentUser, receiver);
            for (Message msg : messages) {
                String prefix = msg.getSender().equals(currentUser) ? "You → " : msg.getSender() + " → ";
                messageArea.append(prefix + msg.getReceiver() + ": " + msg.getBody() + "\n");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void populateReceiverDropdown() {
        receiverDropdown.removeAllItems();
        receiverDropdown.addItem("Select User");

        String currentRole = Session.getCurrentUser().getRole().toLowerCase();
        String targetRole = currentRole.equals("teacher") ? "student" : "teacher";

        UserDAO userDAO = new UserDAO();
        List<String> usernames = userDAO.getUsernamesByRole(targetRole);

        for (String username : usernames) {
            if (!username.equals(Session.getCurrentUser().getUsername())) {
                receiverDropdown.addItem(username);
            }
        }
    }

}
