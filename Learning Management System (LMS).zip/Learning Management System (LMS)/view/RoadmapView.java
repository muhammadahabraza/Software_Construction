package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import java.awt.*;
import controller.RoadmapController;
import model.Roadmap;

public class RoadmapView {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(RoadmapView::showReadOnlyRoadmapView);
    }

    // Create main frame
    public static void showRoadmapView() {
        JFrame frame = new JFrame("Roadmap - Panel");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 400);
        frame.setLayout(new BorderLayout());

        // Table to show roadmap modules
        String[] columns = { "Module Name", "Description", "Sequence" };
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0);
        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        // Admin panel for adding modules
        JPanel inputPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        JTextField nameField = new JTextField();
        JTextField descField = new JTextField();
        JTextField seqField = new JTextField();

        JButton addButton = new JButton("Add Module");
        JButton clearButton = new JButton("Clear");

        inputPanel.add(new JLabel("Module Name:"));
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("Description:"));
        inputPanel.add(descField);
        inputPanel.add(new JLabel("Sequence:"));
        inputPanel.add(seqField);
        inputPanel.add(addButton);
        inputPanel.add(clearButton);

        frame.add(inputPanel, BorderLayout.NORTH);

        // Add module button
        addButton.addActionListener(e -> {
            String name = nameField.getText().trim();
            String desc = descField.getText().trim();
            String seq = seqField.getText().trim();

            if (name.isEmpty() || desc.isEmpty() || seq.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill all fields.");
                return;
            }

            try {
                int sequence = Integer.parseInt(seq);
                Roadmap roadmap = new Roadmap(name, desc, sequence);
                RoadmapController controller = new RoadmapController();
                boolean success = controller.addRoadmap(roadmap);

                if (success) {
                    tableModel.addRow(new Object[] { name, desc, sequence });
                    JOptionPane.showMessageDialog(frame, "Module added successfully.");
                } else {
                    JOptionPane.showMessageDialog(frame, "Failed to add module.");
                }

                nameField.setText("");
                descField.setText("");
                seqField.setText("");
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Sequence must be a number.");
            }
        });

        // Clear input fields
        clearButton.addActionListener(e -> {
            nameField.setText("");
            descField.setText("");
            seqField.setText("");
        });

        frame.setVisible(true);
    }

    // ✅ Read-only view for students
    public static void showReadOnlyRoadmapView() {
        JFrame frame = new JFrame("View Roadmap");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 400);
        frame.setLayout(new BorderLayout());

        // Columns
        String[] columns = { "Module Name", "Description", "Sequence" };
        DefaultTableModel tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // make table read-only
            }
        };

        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        frame.add(scrollPane, BorderLayout.CENTER);

        // 🔁 Fetch roadmap data from DB
        RoadmapController rc = new RoadmapController();
        List<Roadmap> roadmapList = rc.fetchAllRoadmaps();

        for (Roadmap rm : roadmapList) {
            tableModel.addRow(new Object[] {
                    rm.getTitle(),
                    rm.getDescription(),
                    rm.getSequence()
            });
        }

        frame.setVisible(true);
    }
}
