package view;

import controller.EnrollmentController;
import javax.swing.*;
import java.awt.*;
import java.util.List;
import model.User;
import model.Course;

public class EnrollmentsView {

    // Student enrolls in a course
    public static boolean enroll(User user, Course course) {
        if (!user.getRole().equalsIgnoreCase("student")) {
            JOptionPane.showMessageDialog(null, "Only students can enroll in courses.");
            return false;
        }

        EnrollmentController controller = new EnrollmentController();
        boolean success = controller.requestEnrollment(user.getUserId(), course.getCourseId());

        if (success) {
            JOptionPane.showMessageDialog(null, "Enrollment request submitted (Pending Approval)");
        } else {
            JOptionPane.showMessageDialog(null, "You have already enrolled/requested this course.");
        }

        return success;
    }

    // Admin approves enrollment
    public static void showEnrollmentApprovalFrame() {
        JFrame frame = new JFrame("Enrollment Approvals");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(600, 400);
        frame.setLocationRelativeTo(null);

        DefaultListModel<String> listModel = new DefaultListModel<>();
        JList<String> pendingList = new JList<>(listModel);
        JScrollPane scrollPane = new JScrollPane(pendingList);

        EnrollmentController controller = new EnrollmentController();
        List<String[]> pendingEnrollments = controller.getPendingEnrollments(); // Each record: [username, userId,
                                                                                // courseTitle, courseId]

        // Map display string to real data
        java.util.Map<String, String[]> displayMap = new java.util.HashMap<>();
        for (String[] record : pendingEnrollments) {
            String display = "User: " + record[0] + " | Course: " + record[2];
            listModel.addElement(display);
            displayMap.put(display, record);
        }

        JButton approveBtn = new JButton("Approve");
        JButton rejectBtn = new JButton("Reject");
        JButton backBtn = new JButton("Back");

        approveBtn.addActionListener(e -> {
            String selected = pendingList.getSelectedValue();
            if (selected != null) {
                String[] data = displayMap.get(selected);
                int userId = Integer.parseInt(data[1]);
                String courseId = data[3];
                if (controller.approveEnrollment(userId, courseId)) {
                    listModel.removeElement(selected);
                    JOptionPane.showMessageDialog(frame, "Enrollment approved.");
                }
            }
        });

        rejectBtn.addActionListener(e -> {
            String selected = pendingList.getSelectedValue();
            if (selected != null) {
                String[] data = displayMap.get(selected);
                int userId = Integer.parseInt(data[1]);
                String courseId = data[3];
                if (controller.rejectEnrollment(userId, courseId)) {
                    listModel.removeElement(selected);
                    JOptionPane.showMessageDialog(frame, "Enrollment rejected.");
                }
            }
        });

        backBtn.addActionListener(e -> {
            frame.dispose();
            AdminDashBoard.showAdminDashboard();
        });

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(approveBtn);
        buttonPanel.add(rejectBtn);
        buttonPanel.add(backBtn);

        frame.add(scrollPane, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);
        frame.setVisible(true);
    }

}