package controller;

import dao.QuizDAO;
import dao.QuizDAO.Question;

import java.util.List;

public class QuizController {

    private QuizDAO quizDAO;

    public QuizController() {
        this.quizDAO = new QuizDAO();
    }

    // Save a quiz question
    public boolean createQuizQuestion(int quizNumber, String questionText, String[] options, int correctIndex) {
        return quizDAO.saveQuizQuestion(quizNumber, questionText, options, correctIndex);
    }

    // Get all quiz questions
    public List<Question> loadQuizQuestions(int quizNumber) {
        return quizDAO.getQuizQuestions(quizNumber);
    }

    // Save a quiz attempt
    public boolean submitQuizAttempt(String studentUsername, int quizNumber,
            String question, String selectedAnswer,
            String correctAnswer, int marks) {
        return quizDAO.saveQuizAttempt(studentUsername, quizNumber, question, selectedAnswer, correctAnswer, marks);
    }

    // Check if student has already attempted the quiz
    public boolean hasAttempted(String studentUsername, int quizNumber) {
        return quizDAO.hasStudentAttempted(studentUsername, quizNumber);
    }
}
