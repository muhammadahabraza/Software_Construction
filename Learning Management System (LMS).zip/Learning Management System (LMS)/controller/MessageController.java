package controller;

import dao.MessageDAO;
import model.Message;

import java.util.List;

public class MessageController {
    private MessageDAO dao = new MessageDAO();

    public boolean sendMessage(Message msg) {
        return dao.insertMessage(msg);
    }

    public List<Message> getMessagesBetween(String user1, String user2) {
        return dao.getMessagesBetween(user1, user2);
    }
}
