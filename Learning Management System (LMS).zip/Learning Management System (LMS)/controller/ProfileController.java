package controller;

import dao.ProfileDAO;
import model.Profile;

public class ProfileController {
    private ProfileDAO profileDAO;

    public ProfileController() {
        this.profileDAO = new ProfileDAO();
    }

    public boolean saveOrUpdateProfile(Profile profile) {
        Profile existing = profileDAO.getProfileByUserId(profile.getUserId());
        if (existing == null) {
            return profileDAO.saveProfile(profile);
        } else {
            return profileDAO.updateProfile(profile);
        }
    }

    public Profile getProfileByUserId(int userId) {
        return profileDAO.getProfileByUserId(userId);
    }

}
