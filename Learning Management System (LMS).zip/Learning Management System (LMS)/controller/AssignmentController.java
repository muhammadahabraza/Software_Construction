package controller;

import java.util.List;
import dao.AssignmentDAO;
import dao.SubmissionDAO;
import model.Assignment;
import model.Submission;

public class AssignmentController {
    private final AssignmentDAO assignmentDAO = new AssignmentDAO();
    private final SubmissionDAO submissionDAO = new SubmissionDAO();

    public boolean uploadAssignment(Assignment assignment) {
        return assignmentDAO.uploadAssignment(assignment);
    }

    public List<Assignment> getAllAssignments() {
        return assignmentDAO.getAllAssignments();
    }

    public boolean submitAssignment(Submission submission) {
        return submissionDAO.submitAssignment(submission);
    }

    public List<Submission> getSubmissions(int assignmentId) {
        return submissionDAO.getSubmissionsByAssignment(assignmentId);
    }

    public boolean markSubmission(int submissionId, int marks) {
        return submissionDAO.markSubmission(submissionId, marks);
    }
}
