package controller;

import dao.CourseDAO;
import model.Course;

import java.util.ArrayList;
import java.util.List;
import dao.EnrollmentDAO;

public class CourseController {
    private CourseDAO courseDAO;
    private EnrollmentDAO enrollmentDAO = new EnrollmentDAO();

    public CourseController() {
        this.courseDAO = new CourseDAO();
    }

    public List<Course> getAllCourses() {
        return courseDAO.getAllCourses();
    }

    public Course getCourseById(String courseId) {
        return courseDAO.getCourseById(courseId);
    }

    public List<Course> getCoursesForTeacher(int instructorId) {
        List<Course> allCourses = courseDAO.getAllCourses();
        List<Course> teacherCourses = new ArrayList<>();

        for (Course c : allCourses) {
            if (c.getInstructorId() == instructorId) {
                teacherCourses.add(c);
            }
        }
        return teacherCourses;
    }

    public List<Course> getCoursesForStudent(int userId) {
        return enrollmentDAO.getApprovedCourses(userId);
    }

    public boolean addCourse(Course course) {
        return courseDAO.insertCourse(course);
    }
}
