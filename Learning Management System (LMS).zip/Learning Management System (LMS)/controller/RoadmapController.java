package controller;

import dao.RoadmapDAO;
import model.Roadmap;
import dao.DatabaseConnectivity;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class RoadmapController {

    private RoadmapDAO roadmapDAO;

    public RoadmapController() {
        try {
            Connection conn = DatabaseConnectivity.getConnection();
            this.roadmapDAO = new RoadmapDAO(conn);
        } catch (SQLException e) {
            e.printStackTrace(); // You can log this instead in production
        }
    }

    public boolean addRoadmap(Roadmap roadmap) {
        return roadmapDAO.insertRoadmap(roadmap);
    }

    public List<Roadmap> fetchAllRoadmaps() {
        return roadmapDAO.getAllRoadmaps();
    }
}
