package controller;

import dao.EnrollmentDAO;
import model.Course;

import java.util.List;

public class EnrollmentController {

    private EnrollmentDAO enrollmentDAO;

    public EnrollmentController() {
        this.enrollmentDAO = new EnrollmentDAO();
    }

    // Request enrollment (student)
    public boolean requestEnrollment(int userId, String courseId) {
        return enrollmentDAO.requestEnrollment(userId, courseId);
    }

    // Approve enrollment (admin)
    public boolean approveEnrollment(int userId, String courseId) {
        return enrollmentDAO.updateEnrollmentStatus(userId, courseId, "approved");
    }

    // Reject enrollment (admin)
    public boolean rejectEnrollment(int userId, String courseId) {
        return enrollmentDAO.updateEnrollmentStatus(userId, courseId, "rejected");
    }

    // Fetch all pending enrollments (for admin panel)
    public List<String[]> getPendingEnrollments() {
        return enrollmentDAO.getPendingEnrollments();
    }

    // Get all approved courses for a specific student (used in course view)
    public List<Course> getApprovedCourses(int userId) {
        return enrollmentDAO.getApprovedCourses(userId);
    }
}
