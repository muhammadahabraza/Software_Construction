package controller;

import dao.AssessmentDAO;
import model.Assessment;

import java.util.List;

public class AssessmentController {
    private AssessmentDAO dao = new AssessmentDAO();

    public boolean saveOrUpdateAssessment(String studentUsername, int quizMarks, int assignmentMarks, int examMarks) {
        Assessment a = new Assessment(studentUsername, quizMarks, assignmentMarks, examMarks);
        return dao.insertOrUpdateAssessment(a);
    }

    public Assessment getAssessment(String username) {
        return dao.getAssessmentByStudent(username);
    }

    public List<Assessment> getAllAssessments() {
        return dao.getAllAssessments();
    }
}
