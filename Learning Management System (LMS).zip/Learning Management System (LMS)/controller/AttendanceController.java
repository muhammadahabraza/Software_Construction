package controller;

import model.Attendance;
import dao.DatabaseConnectivity;
import dao.LectureAttendanceDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AttendanceController {

    // ✅ Method to mark attendance
    public static boolean markAttendance(Attendance attendance) {
        try {
            Connection conn = DatabaseConnectivity.getConnection();
            LectureAttendanceDAO dao = new LectureAttendanceDAO(conn);

            // Check before inserting
            if (dao.attendanceExists(attendance.getStudentId(), attendance.getDate())) {
                System.out.println("Attendance already marked for this student on this date.");
                return false; // Duplicate
            }

            dao.insertAttendance(attendance);
            return true;

        } catch (SQLException e) {
            System.err.println("Error while saving attendance: " + e.getMessage());
            return false;
        }
    }

    // ✅ Method to fetch full names of all students from Profile table (joined with
    // Users)
    public List<String> getAllStudentNamesFromProfile() {
        List<String> studentNames = new ArrayList<>();
        String sql = """
                    SELECT p.fullname
                    FROM Users u
                    JOIN Profile p
                    ON u.userId = p.userId
                    WHERE u.role = 'student'
                """;

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String fullName = rs.getString("fullname"); // ✅ Use "fullname" here
                System.out.println("Found student: " + fullName); // Optional debug
                studentNames.add(fullName);
            }

            if (studentNames.isEmpty()) {
                System.out.println("⚠️ No student profiles found in database.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return studentNames;
    }

    public boolean isAttendanceAlreadyMarked(int studentId, String date) {
        String sql = "SELECT 1 FROM lecture_attendance WHERE studentId = ? AND date = ?";
        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            stmt.setString(2, date);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Attendance> getAttendanceForStudent(int studentId) {
        List<Attendance> list = new ArrayList<>();
        String sql = """
                    SELECT la.attendance_id, la.teacherId, la.studentId, la.date, la.status,
                           p.fullname AS teacherName
                    FROM lecture_attendance la
                    JOIN Profile p ON la.teacherId = p.userId
                    WHERE la.studentId = ?
                """;

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, studentId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Attendance a = new Attendance();
                a.setId(rs.getInt("attendance_id"));
                a.setUserId(rs.getInt("teacherId"));
                a.setStudentId(rs.getInt("studentId"));
                a.setDate(rs.getString("date"));
                a.setStatus(rs.getString("status"));
                // Optional: store teacher name if needed
                list.add(a);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    public int getStudentIdByName(String fullName) {
        String sql = "SELECT userId FROM Profile WHERE fullname = ?";
        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, fullName);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("userId");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1; // Not found
    }

}
