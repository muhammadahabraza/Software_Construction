package controller;

import dao.UserDAO;
import model.User;
import util.Session;

public class UserController {
    private UserDAO userDAO;

    public UserController() {
        this.userDAO = new UserDAO();
    }

    // Handles registration
    public boolean registerUser(String username, String password, String role) {
        if (userDAO.userExists(username)) {
            System.out.println("User already exists.");
            return false;
        } else {
            User newUser = new User(username, password, role);
            return userDAO.registerUser(newUser);
        }
    }

    // Handles login
    public User loginUser(String username, String password) {
        return userDAO.login(username, password); // now returns null if login fails
    }

    // Check if user exists
    public boolean checkUserExists(String username) {
        return userDAO.userExists(username);
    }

    public boolean registerAndLoginUser(String username, String password, String role) {
        if (userDAO.userExists(username)) {
            return false;
        }

        User newUser = new User(username, password, role);
        boolean registered = userDAO.registerUser(newUser);

        if (registered) {
            User loggedIn = userDAO.login(username, password);
            if (loggedIn != null) {
                Session.setCurrentUser(loggedIn); // 🔹 Save logged-in user globally
                return true;
            }
        }
        return false;
    }

    public User getUserById(int userId) {
        return userDAO.getUserById(userId); // You must implement this in UserDAO
    }
}
