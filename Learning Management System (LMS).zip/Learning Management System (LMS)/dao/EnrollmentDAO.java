
package dao;

import java.sql.*;
import java.util.*;
import model.Course;

public class EnrollmentDAO {

    public boolean requestEnrollment(int userId, String courseId) {
        String sql = "INSERT INTO Enrollment (userId, courseId, status) VALUES (?, ?, 'pending')";

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            stmt.setString(2, courseId);

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateEnrollmentStatus(int userId, String courseId, String status) {
        String sql = "UPDATE Enrollment SET status = ? WHERE userId = ? AND courseId = ?";

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, status);
            stmt.setInt(2, userId);
            stmt.setString(3, courseId);

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<String[]> getPendingEnrollments() {
        List<String[]> pending = new ArrayList<>();
        String sql = "SELECT u.username, e.userId, c.title, e.courseId FROM Enrollment e " +
                "JOIN users u ON e.userId = u.userId " +
                "JOIN Course c ON e.courseId = c.courseId WHERE e.status = 'pending'";

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                pending.add(new String[] {
                        rs.getString("username"),
                        rs.getString("userId"),
                        rs.getString("title"),
                        rs.getString("courseId")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return pending;
    }

    public List<Course> getApprovedCourses(int userId) {
        List<Course> approvedCourses = new ArrayList<>();
        String sql = "SELECT c.* FROM Enrollment e JOIN Course c ON e.courseId = c.courseId " +
                "WHERE e.userId = ? AND e.status = 'approved'";

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Course course = new Course(
                        rs.getString("courseId"),
                        rs.getString("title"),
                        rs.getString("code"),
                        rs.getString("description"),
                        rs.getInt("instructorId"));
                approvedCourses.add(course);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return approvedCourses;
    }

    public String getEnrollmentStatus(int userId, String courseId) {
        String sql = "SELECT status FROM Enrollment WHERE userId = ? AND courseId = ?";
        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            stmt.setString(2, courseId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getString("status");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

}
