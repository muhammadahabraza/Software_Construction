package dao;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseConnectivity {

    private static final String PROPERTIES_FILE = "db.properties";

    private static String url = "jdbc:mysql://localhost:3306/lms";
    private static String user = "root";
    private static String password = "1453";

    static {
        try (InputStream input = DatabaseConnectivity.class.getClassLoader().getResourceAsStream(PROPERTIES_FILE)) {
            Properties prop = new Properties();
            if (input == null) {
                throw new IOException("Unable to find " + PROPERTIES_FILE);
            }
            prop.load(input);
            url = prop.getProperty("db.url", url); // fallback to hardcoded if missing
            user = prop.getProperty("db.user", user);
            password = prop.getProperty("db.password", password);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }
}
