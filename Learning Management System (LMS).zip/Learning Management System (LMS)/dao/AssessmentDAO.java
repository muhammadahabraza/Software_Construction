package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Assessment;

public class AssessmentDAO {

    public boolean insertOrUpdateAssessment(Assessment a) {
        String sql = """
                    INSERT INTO assessments (student_username, quiz_marks, assignment_marks, exam_marks)
                    VALUES (?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE quiz_marks=?, assignment_marks=?, exam_marks=?
                """;

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, a.getStudentUsername());
            stmt.setInt(2, a.getQuizMarks());
            stmt.setInt(3, a.getAssignmentMarks());
            stmt.setInt(4, a.getExamMarks());

            stmt.setInt(5, a.getQuizMarks());
            stmt.setInt(6, a.getAssignmentMarks());
            stmt.setInt(7, a.getExamMarks());

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public Assessment getAssessmentByStudent(String username) {
        String sql = "SELECT * FROM assessments WHERE student_username = ?";
        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Assessment(
                        rs.getInt("id"),
                        rs.getString("student_username"),
                        rs.getInt("quiz_marks"),
                        rs.getInt("assignment_marks"),
                        rs.getInt("exam_marks"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Assessment> getAllAssessments() {
        List<Assessment> list = new ArrayList<>();
        String sql = "SELECT * FROM assessments";

        try (Connection conn = DatabaseConnectivity.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                list.add(new Assessment(
                        rs.getInt("id"),
                        rs.getString("student_username"),
                        rs.getInt("quiz_marks"),
                        rs.getInt("assignment_marks"),
                        rs.getInt("exam_marks")));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
