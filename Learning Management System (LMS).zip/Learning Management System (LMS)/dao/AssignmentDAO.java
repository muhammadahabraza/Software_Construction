package dao;

import java.sql.*;
import java.util.*;
import model.Assignment;

public class AssignmentDAO {
    public boolean uploadAssignment(Assignment assignment) {
        String sql = "INSERT INTO assignments (title, description, file_path, uploaded_by) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, assignment.getTitle());
            stmt.setString(2, assignment.getDescription());
            stmt.setString(3, assignment.getFilePath());
            stmt.setString(4, assignment.getUploadedBy());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Assignment> getAllAssignments() {
        List<Assignment> list = new ArrayList<>();
        String sql = "SELECT * FROM assignments";
        try (Connection conn = DatabaseConnectivity.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new Assignment(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getString("file_path"),
                        rs.getString("uploaded_by")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }
}
