package dao;

import java.sql.*;
import model.Attendance;

public class LectureAttendanceDAO {
    private Connection conn;

    public LectureAttendanceDAO(Connection conn) {
        this.conn = conn;
    }

    public void insertAttendance(Attendance att) throws SQLException {
        String sql = "INSERT INTO lecture_attendance (teacherId, studentId, date, status) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, att.getUserId()); // ✅ teacherId
            stmt.setInt(2, att.getStudentId()); // ✅ studentId — not student_name!
            stmt.setString(3, att.getDate()); // ✅ date
            stmt.setString(4, att.getStatus()); // ✅ status
            stmt.executeUpdate();
        }
    }

    public boolean attendanceExists(int studentId, String date) throws SQLException {
        String sql = "SELECT COUNT(*) FROM lecture_attendance WHERE studentId = ? AND date = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, studentId);
            stmt.setString(2, date);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        }
        return false;
    }
}
