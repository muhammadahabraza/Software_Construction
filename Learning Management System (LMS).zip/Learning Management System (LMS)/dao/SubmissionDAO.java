package dao;

import java.sql.*;
import java.util.*;
import model.Submission;

public class SubmissionDAO {
    public boolean submitAssignment(Submission submission) {
        String sql = "INSERT INTO submissions (assignment_id, student_username, file_path, marks) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, submission.getAssignmentId());
            stmt.setString(2, submission.getStudentUsername());
            stmt.setString(3, submission.getSubmittedFilePath());
            stmt.setInt(4, submission.getMarks());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Submission> getSubmissionsByAssignment(int assignmentId) {
        List<Submission> list = new ArrayList<>();
        String sql = "SELECT * FROM submissions WHERE assignment_id = ?";
        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, assignmentId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                list.add(new Submission(
                        rs.getInt("id"),
                        rs.getInt("assignment_id"),
                        rs.getString("student_username"),
                        rs.getString("file_path"),
                        rs.getInt("marks")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    public boolean markSubmission(int submissionId, int marks) {
        String sql = "UPDATE submissions SET marks = ? WHERE id = ?";
        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, marks);
            stmt.setInt(2, submissionId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static int getSubmissionScore(String studentUsername) {
        String sql = "SELECT SUM(marks) FROM submissions WHERE student_username = ?";
        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, studentUsername);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

}
