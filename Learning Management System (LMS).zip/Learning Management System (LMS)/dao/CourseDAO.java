package dao;

import model.Course;
import java.sql.*;
import java.util.*;

public class CourseDAO {

    // Get all courses
    public List<Course> getAllCourses() {
        List<Course> courses = new ArrayList<>();
        String sql = "SELECT * FROM Course";

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                courses.add(mapResultSetToCourse(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return courses;
    }

    // Add new course
    public boolean insertCourse(Course course) {
        String sql = "INSERT INTO Course (courseId, title, code, description, instructorId) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, course.getCourseId());
            stmt.setString(2, course.getTitle());
            stmt.setString(3, course.getCode());
            stmt.setString(4, course.getDescription());
            stmt.setInt(5, course.getInstructorId());

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Get courses assigned to an instructor
    public List<Course> getCoursesByInstructor(int instructorId) {
        List<Course> courses = new ArrayList<>();
        String sql = "SELECT * FROM Course WHERE instructorId = ?";

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, instructorId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                courses.add(mapResultSetToCourse(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return courses;
    }

    // Get single course
    public Course getCourseById(String courseId) {
        String sql = "SELECT * FROM Course WHERE courseId = ?";

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, courseId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return mapResultSetToCourse(rs);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Update course
    public boolean updateCourse(Course course) {
        String sql = "UPDATE Course SET title = ?, code = ?, description = ?, instructorId = ? WHERE courseId = ?";

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, course.getTitle());
            stmt.setString(2, course.getCode());
            stmt.setString(3, course.getDescription());
            stmt.setInt(4, course.getInstructorId());
            stmt.setString(5, course.getCourseId());

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Delete course
    public boolean deleteCourse(String courseId) {
        String sql = "DELETE FROM Course WHERE courseId = ?";

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, courseId);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Helper method
    private Course mapResultSetToCourse(ResultSet rs) throws SQLException {
        return new Course(
                rs.getString("courseId"),
                rs.getString("title"),
                rs.getString("code"),
                rs.getString("description"),
                rs.getInt("instructorId"));
    }

    // Get courses a student is enrolled in (based on userId)
    public List<Course> getCoursesByStudent(int userId) {
        List<Course> courses = new ArrayList<>();
        String sql = "SELECT c.* FROM Enrollments e " +
                "JOIN Course c ON e.course_id = c.courseId " +
                "WHERE e.user_id = ?";

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                courses.add(mapResultSetToCourse(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return courses;
    }

    public Map<Course, List<String>> getStudentsInInstructorCourses(int instructorId) {
        Map<Course, List<String>> result = new HashMap<>();

        String sql = """
                    SELECT c.courseId, c.title, c.code, c.description, c.instructorId,
                        u.username
                    FROM Enrollment e
                    JOIN Course c ON e.courseId = c.courseId
                    JOIN User u ON e.userId = u.userId
                    WHERE c.instructorId = ? AND e.status = 'approved'
                """;

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, instructorId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Course course = new Course(
                        rs.getString("courseId"),
                        rs.getString("title"),
                        rs.getString("code"),
                        rs.getString("description"),
                        rs.getInt("instructorId"));
                String studentUsername = rs.getString("username");

                result.computeIfAbsent(course, k -> new ArrayList<>()).add(studentUsername);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return result;
    }

}
