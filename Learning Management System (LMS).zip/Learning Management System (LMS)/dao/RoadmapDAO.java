package dao;

import model.Roadmap;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RoadmapDAO {

    private Connection conn;

    public RoadmapDAO(Connection conn) {
        this.conn = conn;
    }

    public boolean insertRoadmap(Roadmap roadmap) {
        String sql = "INSERT INTO roadmap (title, description, sequence) VALUES (?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, roadmap.getTitle());
            stmt.setString(2, roadmap.getDescription());
            stmt.setInt(3, roadmap.getSequence());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Roadmap> getAllRoadmaps() {
        List<Roadmap> list = new ArrayList<>();
        String sql = "SELECT * FROM roadmap";

        try (Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Roadmap roadmap = new Roadmap(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("description"),
                        rs.getInt("sequence"));
                list.add(roadmap);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }
}
