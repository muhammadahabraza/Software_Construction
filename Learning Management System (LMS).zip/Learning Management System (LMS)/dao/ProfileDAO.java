package dao;

import model.Profile;
import java.sql.*;

public class ProfileDAO {

    public boolean saveProfile(Profile profile) {
        String sql = "INSERT INTO Profile (userId, fullName, email, phone, address, dob) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, profile.getUserId());
            stmt.setString(2, profile.getFullName());
            stmt.setString(3, profile.getEmail());
            stmt.setString(4, profile.getPhone());
            stmt.setString(5, profile.getAddress());
            stmt.setString(6, profile.getDob());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateProfile(Profile profile) {
        String sql = "UPDATE Profile SET fullName = ?, email = ?, phone = ?, address = ?, dob = ? WHERE userId = ?";

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, profile.getFullName());
            stmt.setString(2, profile.getEmail());
            stmt.setString(3, profile.getPhone());
            stmt.setString(4, profile.getAddress());
            stmt.setString(5, profile.getDob());
            stmt.setInt(6, profile.getUserId());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public Profile getProfileByUserId(int userId) {
        String sql = "SELECT * FROM Profile WHERE userId = ?";

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Profile(
                        userId,
                        rs.getString("fullName"),
                        rs.getString("email"),
                        rs.getString("phone"),
                        rs.getString("address"),
                        rs.getString("dob"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }
}
