package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class QuizDAO {

    // ✅ Save a quiz question into `quiz_questions`
    public boolean saveQuizQuestion(int quizNumber, String questionText, String[] options, int correctIndex) {
        String sql = "INSERT INTO quiz_questions (quiz_number, question_text, option1, option2, option3, option4, correct_index) "
                +
                "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, quizNumber);
            stmt.setString(2, questionText);
            stmt.setString(3, options[0]);
            stmt.setString(4, options[1]);
            stmt.setString(5, options[2]);
            stmt.setString(6, options[3]);
            stmt.setInt(7, correctIndex);

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // ✅ Load all quiz questions from `quiz_questions`
    public List<Question> getQuizQuestions(int quizNumber) {
        List<Question> questionList = new ArrayList<>();
        String sql = "SELECT * FROM quiz_questions WHERE quiz_number = ?";

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, quizNumber);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String questionText = rs.getString("question_text");
                String[] options = new String[] {
                        rs.getString("option1"),
                        rs.getString("option2"),
                        rs.getString("option3"),
                        rs.getString("option4")
                };
                int correctIndex = rs.getInt("correct_index");

                questionList.add(new Question(questionText, options, correctIndex));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return questionList;
    }

    // ✅ Save a student's quiz attempt into `quiz`
    public boolean saveQuizAttempt(String studentUsername, int quizNumber, String question,
            String selectedAnswer, String correctAnswer, int marks) {
        String sql = "INSERT INTO quiz (quiz_number, student_username, question, selected_answer, correct_answer, marks) "
                +
                "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, quizNumber);
            stmt.setString(2, studentUsername);
            stmt.setString(3, question);
            stmt.setString(4, selectedAnswer);
            stmt.setString(5, correctAnswer);
            stmt.setInt(6, marks);

            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // ✅ Check if a student has already attempted a quiz
    public boolean hasStudentAttempted(String studentUsername, int quizNumber) {
        String sql = "SELECT COUNT(*) FROM quiz WHERE student_username = ? AND quiz_number = ?";

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, studentUsername);
            stmt.setInt(2, quizNumber);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    public static int getQuizScore(String studentUsername) {
        String sql = "SELECT SUM(marks) FROM quiz WHERE student_username = ?";
        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, studentUsername);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    // ✅ Inner class to represent a quiz question
    public static class Question {
        private String questionText;
        private String[] options;
        private int correctIndex;

        public Question(String questionText, String[] options, int correctIndex) {
            this.questionText = questionText;
            this.options = options;
            this.correctIndex = correctIndex;
        }

        public String getQuestionText() {
            return questionText;
        }

        public String[] getOptions() {
            return options;
        }

        public int getCorrectIndex() {
            return correctIndex;
        }
    }
}
