package dao;

import model.Lecture;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LectureDAO {

    // ✅ Save a new lecture
    public boolean insertLecture(Lecture lecture) {
        String sql = "INSERT INTO Lecture (title, date, description, teacher) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, lecture.getTitle());
            stmt.setString(2, lecture.getDate());
            stmt.setString(3, lecture.getDescription());
            stmt.setString(4, lecture.getTeacher());

            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // ✅ Fetch all lectures
    public List<Lecture> fetchAll() {
        List<Lecture> lectures = new ArrayList<>();
        String sql = "SELECT * FROM Lecture";

        try (Connection conn = DatabaseConnectivity.getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Lecture lecture = new Lecture(
                        rs.getString("title"),
                        rs.getString("date"),
                        rs.getString("description"),
                        rs.getString("teacher"));
                lectures.add(lecture);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lectures;
    }
}
