package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Message;

public class MessageDAO {

    public boolean insertMessage(Message message) {
        String sql = "INSERT INTO messages (sender, receiver, subject, body) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, message.getSender());
            stmt.setString(2, message.getReceiver());
            stmt.setString(3, message.getSubject());
            stmt.setString(4, message.getBody());

            int rows = stmt.executeUpdate();
            return rows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Message> getMessagesBetween(String user1, String user2) {
        String sql = "SELECT sender, receiver, subject, body FROM messages " +
                "WHERE (sender = ? AND receiver = ?) OR (sender = ? AND receiver = ?) " +
                "ORDER BY id ASC";

        List<Message> messages = new ArrayList<>();

        try (Connection conn = DatabaseConnectivity.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, user1);
            stmt.setString(2, user2);
            stmt.setString(3, user2);
            stmt.setString(4, user1);

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                messages.add(new Message(
                        rs.getString("sender"),
                        rs.getString("receiver"),
                        rs.getString("subject"),
                        rs.getString("body")));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return messages;
    }
}
