package model;

public class Course {
    private String courseId;
    private String title;
    private String code;
    private String description;
    private int instructorId;

    public Course(String courseId, String title, String code, String description, int instructorId) {
        this.courseId = courseId;
        this.title = title;
        this.code = code;
        this.description = description;
        this.instructorId = instructorId;
    }

    // Getters
    public String getCourseId() {
        return courseId;
    }

    public String getTitle() {
        return title;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public int getInstructorId() {
        return instructorId;
    }

    // Setters
    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setInstructorId(int instructorId) {
        this.instructorId = instructorId;
    }

    @Override
    public String toString() {
        return title + " (" + code + ")";
    }
}
