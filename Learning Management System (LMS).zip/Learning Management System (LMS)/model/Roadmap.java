package model;

public class Roadmap {
    private int id;
    private String title;
    private String description;
    private int sequence;

    public Roadmap(String title, String description, int sequence) {
        this.title = title;
        this.description = description;
        this.sequence = sequence;
    }

    public Roadmap(int id, String title, String description, int sequence) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.sequence = sequence;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public int getSequence() {
        return sequence;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }
}
