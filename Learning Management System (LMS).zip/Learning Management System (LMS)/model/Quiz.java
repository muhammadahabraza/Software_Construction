package model;

public class Quiz {
    private int id;
    private int quizNumber;
    private int studentId;
    private int score;

    public Quiz(int quizNumber, int studentId, int score) {
        this.quizNumber = quizNumber;
        this.studentId = studentId;
        this.score = score;
    }

    public Quiz(int id, int quizNumber, int studentId, int score) {
        this.id = id;
        this.quizNumber = quizNumber;
        this.studentId = studentId;
        this.score = score;
    }

    public int getId() {
        return id;
    }

    public int getQuizNumber() {
        return quizNumber;
    }

    public int getStudentId() {
        return studentId;
    }

    public int getScore() {
        return score;
    }
}
