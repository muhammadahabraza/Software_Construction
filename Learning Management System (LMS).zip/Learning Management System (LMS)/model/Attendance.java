package model;

public class Attendance {
    private int id; // Primary key
    private int userId; // Teacher's user ID
    private int studentId; // Student's user ID
    private String date; // Format: yyyy-MM-dd
    private String status; // Present or Absent

    public Attendance() {
    }

    // Constructor for inserting new records
    public Attendance(int userId, int studentId, String date, String status) {
        this.userId = userId;
        this.studentId = studentId;
        this.date = date;
        this.status = status;
    }

    // Full constructor
    public Attendance(int id, int userId, int studentId, String date, String status) {
        this.id = id;
        this.userId = userId;
        this.studentId = studentId;
        this.date = date;
        this.status = status;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Attendance{" +
                "id=" + id +
                ", userId=" + userId +
                ", studentId=" + studentId +
                ", date='" + date + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
