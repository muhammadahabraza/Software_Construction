package model;

public class Lecture {
    private String title;
    private String description;
    private String teacher;
    private String date;

    public Lecture(String title, String date, String description, String teacher) {
        this.title = title;
        this.date = date;
        this.description = description;
        this.teacher = teacher;
    }

    // Getters
    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getTeacher() {
        return teacher;
    }

    public String getDate() {
        return date;
    }

    // Setters
    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setTeacher(String teacher) {
        this.teacher = teacher;
    }

    public void setDate(String date) {
        this.date = date;
    }

}
