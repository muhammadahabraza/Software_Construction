package model;

public class Assignment {
    private int id;
    private String title;
    private String description;
    private String filePath;
    private String uploadedBy;

    // Full constructor (e.g., loading from DB)
    public Assignment(int id, String title, String description, String filePath, String uploadedBy) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.filePath = filePath;
        this.uploadedBy = uploadedBy;
    }

    // Constructor without ID (e.g., creating before inserting to DB)
    public Assignment(String title, String description, String filePath, String uploadedBy) {
        this.title = title;
        this.description = description;
        this.filePath = filePath;
        this.uploadedBy = uploadedBy;
    }

    // Default constructor
    public Assignment() {
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public void setUploadedBy(String uploadedBy) {
        this.uploadedBy = uploadedBy;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getFilePath() {
        return filePath;
    }

    public String getUploadedBy() {
        return uploadedBy;
    }

    // Important for GUI display in JList or JComboBox
    @Override
    public String toString() {
        return title + " - " + description;
    }
}
