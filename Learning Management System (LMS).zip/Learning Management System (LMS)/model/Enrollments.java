package model;

public class Enrollments {

    public enum Status {
        PENDING, APPROVED, REJECTED
    }

    private int userId;
    private String courseId;
    private Status status;

    public Enrollments(int userId, String courseId, Status status) {
        this.userId = userId;
        this.courseId = courseId;
        this.status = status;
    }

    public int getUserId() {
        return userId;
    }

    public String getCourseId() {
        return courseId;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }
}
