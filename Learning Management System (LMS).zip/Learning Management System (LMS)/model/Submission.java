package model;

public class Submission {
    private int id;
    private int assignmentId;
    private String studentUsername;
    private String submittedFilePath;
    private int marks;

    public Submission(int id, int assignmentId, String studentUsername, String submittedFilePath, int marks) {
        this.id = id;
        this.assignmentId = assignmentId;
        this.studentUsername = studentUsername;
        this.submittedFilePath = submittedFilePath;
        this.marks = marks;
    }

    public Submission(int assignmentId, String studentUsername, String submittedFilePath) {
        this.assignmentId = assignmentId;
        this.studentUsername = studentUsername;
        this.submittedFilePath = submittedFilePath;
        this.marks = -1; // default: unmarked
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setAssignmentId(int assignmentId) {
        this.assignmentId = assignmentId;
    }

    public void setStudentUsername(String studentUsername) {
        this.studentUsername = studentUsername;
    }

    public void setSubmittedFilePath(String submittedFilePath) {
        this.submittedFilePath = submittedFilePath;
    }

    public void setMarks(int marks) {
        this.marks = marks;
    }

    public int getId() {
        return id;
    }

    public int getAssignmentId() {
        return assignmentId;
    }

    public String getStudentUsername() {
        return studentUsername;
    }

    public String getSubmittedFilePath() {
        return submittedFilePath;
    }

    public int getMarks() {
        return marks;
    }
}
