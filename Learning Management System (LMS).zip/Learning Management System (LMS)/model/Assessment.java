package model;

public class Assessment {
    private int id;
    private String studentUsername;
    private int quizMarks;
    private int assignmentMarks;
    private int examMarks;

    public Assessment(String studentUsername, int quizMarks, int assignmentMarks, int examMarks) {
        this.studentUsername = studentUsername;
        this.quizMarks = quizMarks;
        this.assignmentMarks = assignmentMarks;
        this.examMarks = examMarks;
    }

    public Assessment(int id, String studentUsername, int quizMarks, int assignmentMarks, int examMarks) {
        this(studentUsername, quizMarks, assignmentMarks, examMarks);
        this.id = id;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public String getStudentUsername() {
        return studentUsername;
    }

    public int getQuizMarks() {
        return quizMarks;
    }

    public int getAssignmentMarks() {
        return assignmentMarks;
    }

    public int getExamMarks() {
        return examMarks;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setStudentUsername(String studentUsername) {
        this.studentUsername = studentUsername;
    }

    public void setQuizMarks(int quizMarks) {
        this.quizMarks = quizMarks;
    }

    public void setAssignmentMarks(int assignmentMarks) {
        this.assignmentMarks = assignmentMarks;
    }

    public void setExamMarks(int examMarks) {
        this.examMarks = examMarks;
    }
}
