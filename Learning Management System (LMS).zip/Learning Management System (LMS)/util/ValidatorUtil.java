package util;

public class ValidatorUtil {

    // Validates full name (e.g., "John Doe", allows multiple parts like "John
    // Michael Doe")
    public static boolean validateName(String fullname) {
        return fullname.matches("([A-Z][a-z]+\\s)+[A-Z][a-z]+");
    }

    // Validates date of birth in format DD-MM-YYYY
    public static boolean validateDob(String dob) {
        return dob.matches("^(0[1-9]|[12][0-9]|3[01])-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-\\d{4}$");
    }

    // Validates email format
    public static boolean validateEmail(String email) {
        return email.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$");
    }

    // Validates 10-digit phone number (Pakistan: you may want to support +92 too)
    public static boolean validatePhone(String phone) {
        return phone.matches("^\\d{10}$"); // or use "^\\+?92\\d{10}$" for Pakistani format
    }

    // Address must not be empty or just spaces
    public static boolean validateAddress(String address) {
        return address != null && !address.trim().isEmpty();
    }
}
