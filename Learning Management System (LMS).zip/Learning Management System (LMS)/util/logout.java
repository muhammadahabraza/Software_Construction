package util;

import javax.swing.*;
import view.Login;

public class logout {

    public static void logoutsession(JFrame currentFrame) {
        if (currentFrame != null) {
            currentFrame.dispose(); // Close current dashboard window
        }
        Login.main(new String[0]); // Launch login window again
    }
}
